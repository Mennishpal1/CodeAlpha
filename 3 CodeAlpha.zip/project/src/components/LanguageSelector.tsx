import React from 'react';
import { Language } from '../types/translation';
import { languages } from '../data/languages';

interface LanguageSelectorProps {
  value: string;
  onChange: (code: string) => void;
  label: string;
  disabled?: boolean;
}

export function LanguageSelector({ value, onChange, label, disabled }: LanguageSelectorProps) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-sm font-medium text-gray-700">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
      >
        {languages.map((language: Language) => (
          <option key={language.code} value={language.code}>
            {language.name}
          </option>
        ))}
      </select>
    </div>
  );
}