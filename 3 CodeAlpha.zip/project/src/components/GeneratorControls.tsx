import React from 'react';
import { Slider } from 'lucide-react';

interface GeneratorControlsProps {
  temperature: number;
  steps: number;
  onTemperatureChange: (value: number) => void;
  onStepsChange: (value: number) => void;
  disabled?: boolean;
}

export function GeneratorControls({
  temperature,
  steps,
  onTemperatureChange,
  onStepsChange,
  disabled
}: GeneratorControlsProps) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Temperature ({temperature.toFixed(2)})
        </label>
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={temperature}
          onChange={(e) => onTemperatureChange(parseFloat(e.target.value))}
          disabled={disabled}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <p className="text-xs text-gray-500 mt-1">
          Controls randomness (lower = more predictable)
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Steps ({steps})
        </label>
        <input
          type="range"
          min="8"
          max="32"
          step="8"
          value={steps}
          onChange={(e) => onStepsChange(parseInt(e.target.value))}
          disabled={disabled}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <p className="text-xs text-gray-500 mt-1">
          Length of the generated sequence
        </p>
      </div>
    </div>
  );
}