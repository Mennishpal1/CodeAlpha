export interface Note {
  pitch: number;
  quantizedStartStep: number;
  quantizedEndStep: number;
}

export interface GeneratorConfig {
  temperature: number;
  steps: number;
}

export interface Sequence {
  notes: Note[];
  totalQuantizedSteps: number;
}