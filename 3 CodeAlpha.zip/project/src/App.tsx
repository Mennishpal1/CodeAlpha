import React, { useState, useEffect } from 'react';
import { Music, Play, RotateCw } from 'lucide-react';
import { GeneratorControls } from './components/GeneratorControls';
import { initializeModel, generateMelody, playSequence } from './services/musicService';
import { Sequence } from './types/music';

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [temperature, setTemperature] = useState(1.0);
  const [steps, setSteps] = useState(16);
  const [currentSequence, setCurrentSequence] = useState<Sequence | null>(null);

  useEffect(() => {
    initializeModel()
      .then(() => setIsLoading(false))
      .catch((error) => console.error('Failed to initialize:', error));
  }, []);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const sequence = await generateMelody({ temperature, steps });
      setCurrentSequence(sequence);
      playSequence(sequence);
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePlay = () => {
    if (currentSequence) {
      playSequence(currentSequence);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <Music className="mx-auto h-12 w-12 text-indigo-600" />
          <h1 className="mt-3 text-3xl font-extrabold text-gray-900">
            AI Music Generator
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Generate unique melodies using machine learning
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
          <GeneratorControls
            temperature={temperature}
            steps={steps}
            onTemperatureChange={setTemperature}
            onStepsChange={setSteps}
            disabled={isLoading || isGenerating}
          />

          <div className="flex gap-4">
            <button
              onClick={handleGenerate}
              disabled={isLoading || isGenerating}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <RotateCw className="w-5 h-5 animate-spin" />
              ) : (
                'Generate'
              )}
            </button>

            {currentSequence && (
              <button
                onClick={handlePlay}
                disabled={isGenerating}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Play className="w-5 h-5" />
              </button>
            )}
          </div>

          {isLoading && (
            <p className="text-center text-sm text-gray-600">
              Loading AI model...
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;