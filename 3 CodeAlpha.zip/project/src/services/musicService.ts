import * as Tone from 'tone';
import { Note, GeneratorConfig, Sequence } from '../types/music';

// Initialize synthesizer
const synth = new Tone.PolySynth(Tone.Synth).toDestination();

// Create a simpler version that doesn't rely on @magenta/music
const generateNoteSequence = (config: GeneratorConfig): Sequence => {
  const notes: Note[] = [];
  const baseNote = 60; // Middle C
  const scale = [0, 2, 4, 5, 7, 9, 11]; // Major scale intervals

  for (let i = 0; i < config.steps; i++) {
    const randomness = Math.random() * config.temperature;
    const scaleIndex = Math.floor(Math.random() * scale.length);
    const octaveShift = Math.floor(Math.random() * 2) * 12;
    
    const pitch = baseNote + scale[scaleIndex] + octaveShift;
    const duration = Math.floor(Math.random() * 2) + 1;

    notes.push({
      pitch,
      quantizedStartStep: i * 2,
      quantizedEndStep: i * 2 + duration
    });
  }

  return {
    notes,
    totalQuantizedSteps: config.steps * 2
  };
};

export async function initializeModel(): Promise<void> {
  // No initialization needed for our simplified version
  await Tone.start();
  return Promise.resolve();
}

export async function generateMelody(config: GeneratorConfig): Promise<Sequence> {
  try {
    return generateNoteSequence(config);
  } catch (error) {
    console.error('Error generating melody:', error);
    throw new Error('Failed to generate melody');
  }
}

export function playSequence(sequence: Sequence): void {
  const now = Tone.now();
  sequence.notes.forEach((note: Note) => {
    const duration = (note.quantizedEndStep - note.quantizedStartStep) * 0.25; // Adjusted timing
    const time = note.quantizedStartStep * 0.25 + now;
    synth.triggerAttackRelease(Tone.Frequency(note.pitch, "midi"), duration, time);
  });
}