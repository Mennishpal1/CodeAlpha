import React from 'react';
import { RotateCw } from 'lucide-react';

interface TranslationInputProps {
  value: string;
  onChange: (text: string) => void;
  onTranslate: () => void;
  placeholder: string;
  loading?: boolean;
}

export function TranslationInput({ 
  value, 
  onChange, 
  onTranslate, 
  placeholder,
  loading 
}: TranslationInputProps) {
  return (
    <div className="flex flex-col gap-4">
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-32 p-3 border border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
      />
      <button
        onClick={onTranslate}
        disabled={loading || !value.trim()}
        className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? (
          <RotateCw className="w-4 h-4 animate-spin" />
        ) : (
          'Translate'
        )}
      </button>
    </div>
  );
}