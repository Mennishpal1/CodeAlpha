import { FAQ } from '../types/chat';

export const faqs: FAQ[] = [
  {
    question: "What is React?",
    answer: "React is a JavaScript library for building user interfaces, developed by Facebook. It allows developers to create reusable UI components that manage their own state.",
    keywords: ["react", "javascript", "library", "ui", "interface", "facebook", "framework"]
  },
  {
    question: "How do I install React?",
    answer: "You can create a new React project using Create React App by running: 'npx create-react-app my-app' or using Vite with: 'npm create vite@latest my-app -- --template react'",
    keywords: ["install", "setup", "create", "start", "new", "project", "begin"]
  },
  {
    question: "What are React Hooks?",
    answer: "React Hooks are functions that allow you to use state and other React features in functional components. Common hooks include useState, useEffect, and useContext.",
    keywords: ["hooks", "usestate", "useeffect", "state", "functional", "components"]
  },
  {
    question: "What is JSX?",
    answer: "JSX is a syntax extension for JavaScript, recommended for use with React. It allows you to write HTML-like code within JavaScript, making it easier to describe UI components.",
    keywords: ["jsx", "syntax", "html", "javascript", "template"]
  },
  {
    question: "What is Virtual DOM?",
    answer: "Virtual DOM is a programming concept where an ideal, or "virtual", representation of a UI is kept in memory and synced with the "real" DOM by React. This process is called reconciliation.",
    keywords: ["virtual", "dom", "reconciliation", "memory", "performance"]
  }
];