import React, { useState, useRef, useEffect } from 'react';
import { Message } from './types/chat';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { generateResponse, createMessage } from './services/chatService';
import { MessageSquare } from 'lucide-react';

function App() {
  const [messages, setMessages] = useState<Message[]>([
    createMessage(
      "Hi! I'm your React assistant. Ask me anything about React, and I'll do my best to help you!",
      'bot'
    ),
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    // Add user message
    setMessages(prev => [...prev, createMessage(content, 'user')]);
    setIsTyping(true);

    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 500));

    // Generate and add bot response
    const response = generateResponse(content);
    setMessages(prev => [...prev, createMessage(response, 'bot')]);
    setIsTyping(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <MessageSquare className="mx-auto h-12 w-12 text-blue-600" />
          <h1 className="mt-3 text-3xl font-extrabold text-gray-900">
            React FAQ Chatbot
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Ask me anything about React, and I'll help you find the answer
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="h-[600px] overflow-y-auto p-4 space-y-4">
            {messages.map(message => (
              <ChatMessage key={message.id} message={message} />
            ))}
            {isTyping && (
              <div className="flex gap-2 items-center text-gray-500 text-sm">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <Bot size={20} className="text-blue-600" />
                </div>
                <div>Typing...</div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-4 border-t">
            <ChatInput onSend={handleSendMessage} disabled={isTyping} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;