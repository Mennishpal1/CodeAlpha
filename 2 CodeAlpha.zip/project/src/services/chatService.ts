import { findBestMatch } from 'string-similarity';
import { faqs } from '../data/faqData';
import { Message } from '../types/chat';

function preprocessText(text: string): string {
  return text.toLowerCase().trim();
}

export function generateResponse(userMessage: string): string {
  const processedInput = preprocessText(userMessage);
  
  // Create an array of all questions and their keywords
  const searchSpace = faqs.map(faq => ({
    text: preprocessText(faq.question),
    keywords: faq.keywords.join(' '),
    answer: faq.answer
  }));

  // Find best match among questions and keywords
  const matches = searchSpace.map(item => ({
    rating: findBestMatch(processedInput, [item.text, item.keywords]).bestMatch.rating,
    answer: item.answer
  }));

  // Sort by rating and get the best match
  const bestMatch = matches.sort((a, b) => b.rating - a.rating)[0];

  // Return default message if no good match found
  if (bestMatch.rating < 0.3) {
    return "I'm not sure about that. Could you rephrase your question or ask something about React, its installation, hooks, JSX, or Virtual DOM?";
  }

  return bestMatch.answer;
}

export function createMessage(content: string, sender: 'user' | 'bot'): Message {
  return {
    id: Math.random().toString(36).substr(2, 9),
    content,
    sender,
    timestamp: new Date()
  };
}