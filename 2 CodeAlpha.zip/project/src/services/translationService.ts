import { TranslationResult } from '../types/translation';

export async function translateText(
  text: string,
  targetLang: string,
  sourceLang: string
): Promise<TranslationResult> {
  try {
    const response = await fetch('https://libretranslate.de/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: text,
        source: sourceLang,
        target: targetLang,
      }),
    });

    if (!response.ok) {
      throw new Error('Translation failed');
    }

    const data = await response.json();
    return {
      translatedText: data.translatedText,
    };
  } catch (error) {
    console.error('Translation error:', error);
    throw new Error('Translation failed. Please try again later.');
  }
}