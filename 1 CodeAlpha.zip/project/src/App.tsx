import React from 'react';
import { TranslationTool } from './components/TranslationTool';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <TranslationTool />
    </div>
  );
}

export default App;