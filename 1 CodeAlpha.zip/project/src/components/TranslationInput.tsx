import React from 'react';

interface TranslationInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  readonly?: boolean;
}

export function TranslationInput({
  value,
  onChange,
  placeholder,
  readonly = false,
}: TranslationInputProps) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      readOnly={readonly}
      className="w-full h-32 p-3 border border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
    />
  );
}