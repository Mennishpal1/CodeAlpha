import React, { useState } from 'react';
import { Globe2 } from 'lucide-react';
import { LanguageSelector } from './LanguageSelector';
import { TranslationInput } from './TranslationInput';
import { translateText } from '../utils/translationService';
import { LANGUAGES } from '../utils/constants';

export function TranslationTool() {
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleTranslate = async () => {
    if (!sourceText.trim()) return;

    setIsLoading(true);
    setError(null);
    setTranslatedText('');

    try {
      const result = await translateText(sourceText, sourceLang, targetLang);
      setTranslatedText(result);
    } catch (err) {
      const errorMessage = err instanceof Error 
        ? err.message 
        : 'Translation failed. Please try again later.';
      setError(`Translation failed: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-center gap-2 text-2xl font-bold text-gray-800">
        <Globe2 className="w-8 h-8" />
        <h1>Language Translator</h1>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <LanguageSelector
          languages={LANGUAGES}
          value={sourceLang}
          onChange={setSourceLang}
          label="From"
        />
        <LanguageSelector
          languages={LANGUAGES}
          value={targetLang}
          onChange={setTargetLang}
          label="To"
        />
      </div>

      <div className="space-y-4">
        <TranslationInput
          value={sourceText}
          onChange={setSourceText}
          placeholder="Enter text to translate..."
        />
        <button
          onClick={handleTranslate}
          disabled={isLoading || !sourceText.trim()}
          className="w-full py-2 px-4 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? 'Translating...' : 'Translate'}
        </button>
        <TranslationInput
          value={translatedText}
          onChange={() => {}}
          placeholder="Translation will appear here..."
          readonly
        />
      </div>

      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}
    </div>
  );
}