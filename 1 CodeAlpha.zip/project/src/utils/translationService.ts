import { TranslationRequest, TranslationResponse } from '../types/translation';

const API_URLS = [
  'https://libretranslate.de/translate',
  'https://translate.argosopentech.com/translate'
];

async function tryTranslate(
  url: string,
  text: string,
  sourceLang: string,
  targetLang: string
): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

  try {
    const response = await fetch(url, {
      method: 'POST',
      signal: controller.signal,
      body: JSON.stringify({
        q: text,
        source: sourceLang,
        target: targetLang,
        format: 'text',
        api_key: ''
      } as TranslationRequest),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const data = await response.json().catch(() => ({ error: 'Invalid response' }));
      throw new Error(data.error || `HTTP error! status: ${response.status}`);
    }

    const data: TranslationResponse = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }

    return data.translatedText;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

export async function translateText(
  text: string,
  sourceLang: string,
  targetLang: string
): Promise<string> {
  let lastError: Error | null = null;

  // Try each API endpoint
  for (const url of API_URLS) {
    try {
      return await tryTranslate(url, text, sourceLang, targetLang);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error('Unknown error occurred');
      console.warn(`Translation failed for ${url}:`, lastError.message);
      continue; // Try next API endpoint
    }
  }

  // If we get here, all attempts failed
  throw new Error(lastError?.message || 'All translation attempts failed');
}