export interface Language {
  code: string;
  name: string;
}

export interface TranslationRequest {
  q: string;
  source: string;
  target: string;
  format?: string;
  api_key?: string;
}

export interface TranslationResponse {
  translatedText: string;
  error?: string;
}